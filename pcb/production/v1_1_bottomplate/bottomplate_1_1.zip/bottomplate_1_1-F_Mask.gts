G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.5*
G04 #@! TF.CreationDate,2024-11-18T19:47:06+09:00*
G04 #@! TF.ProjectId,bottomplate_1_1,626f7474-6f6d-4706-9c61-74655f315f31,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.5) date 2024-11-18 19:47:06*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,Ref\u002A\u002A*
X140493750Y-35718750D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X16668750Y-35718750D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X16668750Y-69056250D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X140493750Y-88106250D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X57150000Y-16668750D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X57150000Y-102393750D03*
G04 #@! TD*
M02*
