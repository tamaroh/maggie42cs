G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.8*
G04 #@! TF.CreationDate,2025-02-17T21:23:55+09:00*
G04 #@! TF.ProjectId,bottom,626f7474-6f6d-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.8) date 2025-02-17 21:23:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,Ref\u002A\u002A*
X29481250Y-50931250D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X153306250Y-50931250D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X29481250Y-84268750D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X69962500Y-117606250D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X153306250Y-103318750D03*
G04 #@! TD*
G04 #@! TO.C,Ref\u002A\u002A*
X69962500Y-31881250D03*
G04 #@! TD*
M02*
